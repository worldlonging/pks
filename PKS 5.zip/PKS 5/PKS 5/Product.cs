﻿namespace WarehouseManagement
{
    public class Product
    {
        // Свойства товара
        public int Id { get; private set; } // Уникальный идентификатор товара
        public int SupplierId { get; private set; } // Идентификатор поставщика
        public string Name { get; private set; } // Название товара
        public double Volume { get; private set; } // Объем одной единицы товара
        public double Price { get; private set; } // Цена одной единицы товара
        public int DaysUntilExpiry { get; private set; } // Количество дней до окончания срока годности

        // Конструктор
        public Product(int id, int supplierId, string name, double volume, double price, int daysUntilExpiry)
        {
            Id = id;
            SupplierId = supplierId;
            Name = name;
            Volume = volume;
            Price = price;
            DaysUntilExpiry = daysUntilExpiry;
        }

        // Метод создания товара (статический метод для удобства)
        public static Product CreateProduct(int id, int supplierId, string name, double volume, double price, int daysUntilExpiry)
        {
            return new Product(id, supplierId, name, volume, price, daysUntilExpiry);
        }

        // Метод изменения информации о товаре
        public void EditProduct(int supplierId, string name, double volume, double price, int daysUntilExpiry)
        {
            SupplierId = supplierId;
            Name = name;
            Volume = volume;
            Price = price;
            DaysUntilExpiry = daysUntilExpiry;
        }

        // Метод вывода информации о товаре
        public void PrintProductInfo()
        {
            Console.WriteLine($"Товар {Id}:");
            Console.WriteLine($"Поставщик: {SupplierId}");
            Console.WriteLine($"Название: {Name}");
            Console.WriteLine($"Объем одной единицы: {Volume}");
            Console.WriteLine($"Цена одной единицы: {Price}");
            Console.WriteLine($"Дней до окончания срока годности: {DaysUntilExpiry}");
        }

        // Метод удаления товара
        public void DeleteProduct()
        {
            Console.WriteLine($"Товар {Id} ({Name}) был удален.");
        }
    }
}
