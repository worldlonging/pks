﻿using System;
using System.Collections.Generic;

namespace WarehouseManagement
{
    public class Warehouse
    {
        // Свойства склада
        public int Id { get; private set; } // Уникальный идентификатор склада
        public string Type { get; private set; } // Тип склада (холодный, сортировочный, общий, утилизация)
        public double Capacity { get; private set; } // Общий объем склада
        public string Address { get; private set; } // Адрес склада
        public List<Product> Products { get; private set; } // Список товаров, хранящихся на складе

        // Конструктор
        public Warehouse(int id, string type, double capacity, string address)
        {
            Id = id;
            Type = type;
            Capacity = capacity;
            Address = address;
            Products = new List<Product>();
        }

        // Метод создания склада (допустимо вызов конструктора)
        public static Warehouse CreateWarehouse(int id, string type, double capacity, string address)
        {
            return new Warehouse(id, type, capacity, address);
        }

        // Метод редактирования информации о складе
        public void EditWarehouse(string newType, double newCapacity, string newAddress)
        {
            Type = newType;
            Capacity = newCapacity;
            Address = newAddress;
        }

        // Метод добавления товара на склад
        public void AddProduct(Product product)
        {
            double currentVolume = GetCurrentVolume();
            if (currentVolume + product.Volume > Capacity)
            {
                Console.WriteLine($"Недостаточно места на складе {Id} для добавления товара {product.Name}");
            }
            else
            {
                Products.Add(product);
                //Console.WriteLine($"Товар {product.Name} добавлен на склад {Id}");
            }
        }

        // Метод получения информации о складе
        public void PrintWarehouseInfo()
        {
            Console.WriteLine($"Склад {Id}:");
            Console.WriteLine($"Тип: {Type}");
            Console.WriteLine($"Адрес: {Address}");
            Console.WriteLine($"Объем: {Capacity} (занято {GetCurrentVolume()} / {Capacity})");
            Console.WriteLine("Товары:");
            foreach (var product in Products)
            {
                Console.WriteLine($"- {product.Name} (ID: {product.Id}, Объем: {product.Volume}, Цена: {product.Price})");
            }
        }

        // Метод подсчета текущего занятого объема склада
        public double GetCurrentVolume()
        {
            double totalVolume = 0;
            foreach (var product in Products)
            {
                totalVolume += product.Volume;
            }
            return totalVolume;
        }
    }
}
