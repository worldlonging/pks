﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WarehouseManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            // Включаем кодировку UTF-8 для русского
            Console.OutputEncoding = Encoding.UTF8;

            // Создаем склады
            var warehouses = new List<Warehouse>
            {
                Warehouse.CreateWarehouse(1, "Общий", 1000, "Адрес 1"),
                Warehouse.CreateWarehouse(2, "Холодный", 800, "Адрес 2"),
                Warehouse.CreateWarehouse(3, "Сортировочный", 1200, "Адрес 3"),
                Warehouse.CreateWarehouse(4, "Утилизация", 500, "Адрес 4")
            };

            // Пример поставки товаров
            var delivery1 = new List<Product>
            {
                Product.CreateProduct(1, 101, "Гречка", 20, 1.5, 48),
                Product.CreateProduct(2, 102, "Рис", 10, 0.8, 45),
                Product.CreateProduct(3, 103, "Овес", 50, 5.0, 50)
            };

            // Обрабатываем поставку
            HandleDelivery(delivery1, warehouses);

            // Пример поставки товаров
            var delivery2 = new List<Product>
            {
                Product.CreateProduct(4, 101, "Молоко парное", 20, 1.5, 10),
                Product.CreateProduct(5, 102, "Рыба атлантичская", 10, 0.8, 15),
                Product.CreateProduct(6, 103, "Мясо мех. обвалки", 50, 5.0, 15)
            };

            // Обрабатываем поставку
            HandleDelivery(delivery2, warehouses);

            // Пример поставки товаров
            var delivery3 = new List<Product>
            {
                Product.CreateProduct(7, 101, "Яйца", 20, 1.5, 25),
                Product.CreateProduct(8, 102, "Макароны улитки", 10, 0.8, 55),
                Product.CreateProduct(9, 103, "Креветки тихоокеанские", 50, 5.0, -5)
            };

            // Обрабатываем поставку
            HandleDelivery(delivery3, warehouses);

            // Внутреннее перемещение товаров
            OptimizeWarehouseStorage(warehouses);

            // Ручное перемещение товаров
            MoveProduct(warehouses, 2, 1, 4);
            MoveProduct(warehouses, 2, 3, 5);
            MoveProduct(warehouses, 1, 4, 1);
            MoveProduct(warehouses, 1, 2, 2);
            MoveProduct(warehouses, 1, 3, 3);

            // Анализ складской сети
            AnalyzeWarehouses(warehouses);

            // Перемещение просроченных товаров
            MoveExpiredProducts(warehouses);

            // Внутреннее перемещение товаров
            OptimizeWarehouseStorage(warehouses);

            // Анализ складской сети
            AnalyzeWarehouses(warehouses);

            // Подсчет стоимости товаров на складе
            CalculateWarehouseValue(warehouses[0]);
        }

        // Метод обработки поставки товаров
        static void HandleDelivery(List<Product> delivery, List<Warehouse> warehouses)
        {
            string targetType = GetWarehouseTypeForDelivery(delivery);
            Console.WriteLine($"Поставка будет направлена на склады типа: {targetType}");

            foreach (var warehouse in warehouses.Where(w => w.Type == targetType))
            {
                foreach (var product in delivery.ToList())
                {
                    if (warehouse.GetCurrentVolume() + product.Volume <= warehouse.Capacity)
                    {
                        warehouse.AddProduct(product);
                        delivery.Remove(product);
                        LogAction(product, "Поставка", "Склад", warehouse.Id);
                    }
                }
            }

            if (delivery.Any())
            {
                Console.WriteLine("Не все товары были размещены из-за нехватки места.");
            }
        }

        // Определение типа склада для поставки
        static string GetWarehouseTypeForDelivery(List<Product> delivery)
        {
            bool allLongTerm = delivery.All(p => p.DaysUntilExpiry >= 30);
            bool allShortTerm = delivery.All(p => p.DaysUntilExpiry < 30);

            if (allLongTerm) return "Общий";
            if (allShortTerm) return "Холодный";
            return "Сортировочный";
        }

        // Метод анализа складской сети
        static void AnalyzeWarehouses(List<Warehouse> warehouses)
        {
            Console.WriteLine("Анализ складской системы:");
            foreach (var warehouse in warehouses)
            {
                // Анализ для общего склада
                if (warehouse.Type == "Общий")
                {
                    foreach (var product in warehouse.Products.Where(p => p.DaysUntilExpiry < 30))
                    {
                        // На общем складе оказался товар с коротким сроком хранения (холодный товар)
                        var coldStorageWarehouse = warehouses.FirstOrDefault(w => w.Type == "Холодный");
                        if (coldStorageWarehouse != null && coldStorageWarehouse.GetCurrentVolume() + product.Volume <= coldStorageWarehouse.Capacity)
                        {
                            Console.WriteLine($"На общем складе {warehouse.Id} находится товар с коротким сроком хранения ({product.Name}). " +
                                              $"Необходимо перемещение на склад Холодный {coldStorageWarehouse.Id}.");
                        }
                    }
                }

                // Анализ для холодного склада
                if (warehouse.Type == "Холодный")
                {
                    foreach (var product in warehouse.Products.Where(p => p.DaysUntilExpiry >= 30))
                    {
                        // На холодном складе оказался товар с длительным сроком хранения (общий товар)
                        var commonStorageWarehouse = warehouses.FirstOrDefault(w => w.Type == "Общий");
                        if (commonStorageWarehouse != null && commonStorageWarehouse.GetCurrentVolume() + product.Volume <= commonStorageWarehouse.Capacity)
                        {
                            Console.WriteLine($"На складе Холодный {warehouse.Id} находится товар с длительным сроком хранения ({product.Name}). " +
                                              $"Необходимо перемещение на склад Общий {commonStorageWarehouse.Id}.");
                        }
                    }
                }

                // Анализ для сортировочного склада
                if (warehouse.Type == "Сортировочный" && warehouse.Products.Any())
                {
                    Console.WriteLine($"Сортировочный склад {warehouse.Id} не пуст. Необходимо перемещение товаров на следующие склады:");

                    // Для каждого товара в сортировочном складе определяем, на какой склад его нужно переместить
                    var coldStorage = warehouses.FirstOrDefault(w => w.Type == "Холодный");
                    var commonStorage = warehouses.FirstOrDefault(w => w.Type == "Общий");

                    if (coldStorage != null && coldStorage.GetCurrentVolume() + warehouse.Products.Sum(p => p.Volume) <= coldStorage.Capacity)
                    {
                        Console.WriteLine($"- На склад Холодный {coldStorage.Id}");
                    }

                    if (commonStorage != null && commonStorage.GetCurrentVolume() + warehouse.Products.Sum(p => p.Volume) <= commonStorage.Capacity)
                    {
                        Console.WriteLine($"- На склад Общий {commonStorage.Id}");
                    }
                }

                // Анализ для склада утилизации
                if (warehouse.Type == "Утилизация")
                {
                    foreach (var product in warehouse.Products.Where(p => p.DaysUntilExpiry > 0))
                    {
                        // На складе утилизации есть товар с не истекшим сроком годности
                        var targetWarehouse = warehouses.FirstOrDefault(w => (w.Type == "Холодный" || w.Type == "Общий") &&
                                                                            w.GetCurrentVolume() + product.Volume <= w.Capacity);

                        if (targetWarehouse != null) // Проверяем, что склад утилизации не является местом назначения
                        {
                            Console.WriteLine($"На складе Утилизация {warehouse.Id} есть товар с не истекшим сроком годности ({product.Name}). " +
                                              $"Необходимо перемещение на склад {targetWarehouse.Id} ({targetWarehouse.Type}).");
                        }
                    }
                }

                // Анализ для всех складов на наличие просроченных товаров
                if (warehouse.Products.Any(p => p.DaysUntilExpiry <= 0))
                {
                    var disposalWarehouse = warehouses.FirstOrDefault(w => w.Type == "Утилизация");
                    if (disposalWarehouse != null && disposalWarehouse.Type != "Утилизация") { 
                        Console.WriteLine($"На складе {warehouse.Id} есть товар с истекшим сроком годности. Необходимо перемещение на склад Утилизация {(disposalWarehouse != null ? disposalWarehouse.Id.ToString() : "не найден")}.");
                    }
                }
            }
            Console.WriteLine("Конец анализа складской системы.");
        }

        // Метод оптимизации сортировочных складов
        static void OptimizeWarehouseStorage(List<Warehouse> warehouses)
        {
            Console.WriteLine($"Оптимизация складов:");

            foreach (var sortingWarehouse in warehouses.Where(w => w.Type == "Сортировочный"))
            {
                // Перебираем все товары на сортировочном складе
                foreach (var product in sortingWarehouse.Products.ToList())
                {
                    // Если товар имеет истекший срок годности, его нужно переместить на склад утилизации
                    if (product.DaysUntilExpiry <= 0)
                    {
                        var disposalWarehouse = warehouses.FirstOrDefault(w => w.Type == "Утилизация" && w.GetCurrentVolume() + product.Volume <= w.Capacity);

                        // Перемещаем товар на склад утилизации, если он есть и на нем достаточно места
                        if (disposalWarehouse != null)
                        {
                            disposalWarehouse.AddProduct(product);
                            sortingWarehouse.Products.Remove(product);
                            LogAction(product, "Оптимизация", sortingWarehouse.Id, disposalWarehouse.Id);
                        }
                    }
                    else
                    {
                        // Если товар не испорчен, то его нужно направить на склад с нужным типом (Холодный или Общий)
                        string targetType = product.DaysUntilExpiry < 30 ? "Холодный" : "Общий";
                        var targetWarehouse = warehouses.FirstOrDefault(w => w.Type == targetType && w.GetCurrentVolume() + product.Volume <= w.Capacity);

                        if (targetWarehouse != null)
                        {
                            targetWarehouse.AddProduct(product);
                            sortingWarehouse.Products.Remove(product);
                            LogAction(product, "Оптимизация", sortingWarehouse.Id, targetWarehouse.Id);
                        }
                    }
                }
            }

            Console.WriteLine($"Оптимизация закончена.");
        }


        // Метод перемещения просроченных товаров
        static void MoveExpiredProducts(List<Warehouse> warehouses)
        {
            // Получаем все склады утилизации
            var disposalWarehouses = warehouses.Where(w => w.Type == "Утилизация").ToList();

            bool foundExpiredProduct = false; // Флаг для отслеживания наличия просроченных товаров

            // Перебираем все склады
            foreach (var warehouse in warehouses)
            {
                // Перебираем все товары на складе с истекшим сроком годности
                foreach (var product in warehouse.Products.Where(p => p.DaysUntilExpiry <= 0).ToList())
                {
                    foundExpiredProduct = true; // Находим хотя бы один просроченный товар

                    // Перебираем все склады утилизации
                    foreach (var disposalWarehouse in disposalWarehouses)
                    {
                        // Проверяем, что склад утилизации не является тем же, с которого товар был перемещен
                        if (disposalWarehouse.Id != warehouse.Id && disposalWarehouse.GetCurrentVolume() + product.Volume <= disposalWarehouse.Capacity)
                        {
                            // Перемещаем товар
                            disposalWarehouse.AddProduct(product);
                            warehouse.Products.Remove(product);

                            // Логирование перемещения
                            LogAction(product, warehouse.Id, disposalWarehouse.Id);

                            break; // Выход из цикла после успешного перемещения
                        }
                    }
                }
            }

            // Если не было найдено просроченных товаров
            if (!foundExpiredProduct)
            {
                Console.WriteLine("Не найдено товаров с истекшим сроком годности для перемещения.");
            }
        }


        // Метод подсчета стоимости товаров на складе
        static void CalculateWarehouseValue(Warehouse warehouse)
        {
            double totalValue = warehouse.Products.Sum(p => p.Price);
            Console.WriteLine($"Общая стоимость товаров на складе {warehouse.Id}: {totalValue}");
        }

        // Метод перемещения товара с одного склада на другой
        static void MoveProduct(List<Warehouse> warehouses, int fromWarehouseId, int toWarehouseId, int productId)
        {
            // Поиск складов по Id
            var fromWarehouse = warehouses.FirstOrDefault(w => w.Id == fromWarehouseId);
            var toWarehouse = warehouses.FirstOrDefault(w => w.Id == toWarehouseId);

            // Проверка, что оба склада найдены
            if (fromWarehouse == null)
            {
                Console.WriteLine($"Склад с ID {fromWarehouseId} не найден.");
                return;
            }
            if (toWarehouse == null)
            {
                Console.WriteLine($"Склад с ID {toWarehouseId} не найден.");
                return;
            }

            // Поиск товара на исходном складе
            var product = fromWarehouse.Products.FirstOrDefault(p => p.Id == productId);

            if (product == null)
            {
                Console.WriteLine($"Товар с ID {productId} отсутствует на складе {fromWarehouseId}.");
                return;
            }

            // Проверка вместимости целевого склада
            if (toWarehouse.GetCurrentVolume() + product.Volume > toWarehouse.Capacity)
            {
                Console.WriteLine($"Недостаточно места на складе {toWarehouseId} для перемещения товара {product.Name}.");
                return;
            }

            // Перемещение товара
            fromWarehouse.Products.Remove(product);
            toWarehouse.AddProduct(product);

            // Логирование перемещения
            LogAction(product, "Перемещение", fromWarehouse.Id, toWarehouse.Id);
        }


        // Метод для логирования действий
        // Метод с тремя аргументами
        static void LogAction(Product product, object from, object to)
        {
            Console.WriteLine($"Товар: {product.Name}, Объем: {product.Volume}, Откуда: {from}, Куда: {to}");
        }

        // Перегруженный метод с четырьмя аргументами
        static void LogAction(Product product, string action, object from, object to)
        {
            Console.WriteLine($"Товар: {product.Name}, Объем: {product.Volume}, Действие: {action}, Откуда: {from}, Куда: {to}");
        }

    }
}
